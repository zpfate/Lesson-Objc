//
//  TFThread.m
//  RunLoopAppDemo
//
//  Created by Twisted Fate on 2022/3/30.
//

#import "TFThread.h"

@implementation TFThread
- (void)dealloc {
    NSLog(@"%s", __func__);
}
@end
