//
//  AppDelegate.h
//  RunLoopAppDemo
//
//  Created by Twisted Fate on 2022/3/30.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

