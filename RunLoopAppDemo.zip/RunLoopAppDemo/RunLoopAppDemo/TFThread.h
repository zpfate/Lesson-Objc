//
//  TFThread.h
//  RunLoopAppDemo
//
//  Created by Twisted Fate on 2022/3/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TFThread : NSThread

@end

NS_ASSUME_NONNULL_END
